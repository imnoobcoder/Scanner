package com.iqtek.scanner;

import android.app.Activity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

public class BarcodeScannerHelper {

    private Activity activity;
    private GmsBarcodeScanner scanner;
    private String lastValue = "";
    private int stableCount = 0;
    private static final int REQUIRED_STABLE_COUNT = 3;

    public BarcodeScannerHelper(Activity activity) {
        this.activity = activity;

        GmsBarcodeScannerOptions options =
                new GmsBarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                        .enableAutoZoom()
                        .build();

        scanner = GmsBarcodeScanning.getClient(activity, options);
    }

    public void startScan(OnSuccessListener<String> onSuccess,
                          OnFailureListener onFailure,
                          Runnable onCancel) {

        scanner.startScan()
                .addOnSuccessListener(barcode -> {
                    if (barcode == null || barcode.getRawValue() == null)
                        return;

                    String value = barcode.getRawValue().trim();

                   /* if (!value.matches("\\d{8,10}"))
                        return;*/

            /*        if (value.equals(lastValue)) {
                        stableCount++;
                    } else {
                        stableCount = 1;
                        lastValue = value;
                    }

                    if (stableCount >= REQUIRED_STABLE_COUNT) {
                        stableCount = 0;*/
                        onSuccess.onSuccess(value);
                    //}
                })
                .addOnFailureListener(onFailure)
                .addOnCanceledListener(onCancel::run);
    }

}
